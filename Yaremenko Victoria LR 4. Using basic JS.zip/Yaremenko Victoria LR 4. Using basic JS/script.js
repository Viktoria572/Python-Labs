// script.js
function handleSearch() {
    const searchText = document.querySelector('.search-input').value;
    alert('Користувач ввів: ' + searchText);
}

function handleImageSearch() {
    const searchInput = document.getElementById('image-search-input');
    const searchText = searchInput.value;
    confirm('Ви впевнені, що хочете шукати зображення з запитом: ' + searchText);
}

function handleAdvancedSearch() {
    const allWords = document.getElementById('all-words').value;
    const exactPhrase = document.getElementById('exact-phrase').value;
    const anyWords = document.getElementById('any-words').value;
    const noneWords = document.getElementById('none-words').value;

    // Використання alert для кожного введеного значення
    alert('Знайти сторінки із: ' + allWords);
    alert('Знайти сторінки з: ' + exactPhrase);
    alert('Знайти сторінки з будь-яким із цих слів: ' + anyWords);
    alert('Знайти сторінки з жодним із цих слів: ' + noneWords);
}
